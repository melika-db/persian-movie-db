SELECT g.GenreName,
 AVG(m.Score) AS AverageIMDBScore
FROM Movie m
JOIN MovieGenres mg ON m.MovieID = mg.MovieID
JOIN Genres g ON mg.GenreID = g.GenreID
GROUP BY g.GenreName
ORDER BY AverageIMDBScore DESC;

