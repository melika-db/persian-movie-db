SELECT 
    g.GenreName,
    COUNT(m.MovieID) AS MovieCount,
    AVG(m.Score) AS AverageScore
FROM Movie m
JOIN MovieGenres mg ON m.MovieID = mg.MovieID
JOIN Genres g ON mg.GenreID = g.GenreID
GROUP BY g.GenreName 
