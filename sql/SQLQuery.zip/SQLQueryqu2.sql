SELECT 
g.GenreName, m.PERSIAN_title, m.EN_title, m.Score
FROM Movie m
JOIN MovieGenres mg ON m.MovieID = mg.MovieID
JOIN Genres g ON mg.GenreID = g.GenreID
WHERE m.Score = (
    SELECT MAX(m2.Score)
    FROM Movie m2
    JOIN MovieGenres mg2 ON m2.MovieID = mg2.MovieID
    WHERE mg2.GenreID = g.GenreID
);