SELECT 
    MovieID,
    EN_title,PERSIAN_title, Time, Score
FROM Movie
WHERE Time > 90
  AND Score > 7;

