SELECT 
    MovieID,
    PERSIAN_title ,
    EN_title,
    Score ,
    Time,Year
FROM Movie
WHERE Year = 2018
ORDER BY Score DESC