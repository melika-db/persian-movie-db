
INSERT INTO MovieGenres (MovieID, GenreID) VALUES (1, 1);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (2, 16);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (3, 1);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (4, 1);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (5, 1);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (6, 20), (6, 21);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (7, 2);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (8, 1);
GO

INSERT INTO MovieGenres (MovieID, GenreID) VALUES (9, 1);
GO


INSERT INTO MovieGenres (MovieID, GenreID) VALUES (10, 1);
GO
